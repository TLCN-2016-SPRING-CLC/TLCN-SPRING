package com.tlcn.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tlcn.model.User;

@Repository
public class UserDAOImpl implements UserDAO {
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public boolean checkLogin(User user, int role) {

		List<User> users = new ArrayList<User>();
		
		users = sessionFactory.getCurrentSession().createQuery("from User where username=? and password=? and isadmin=?").
				setParameter(0, user.getUsername()).setParameter(1, user.getPassword()).setParameter(2, role)
				.list();

		if (users.size() > 0) {
			return true;
		} else {
			return false;
		}

	}
}
