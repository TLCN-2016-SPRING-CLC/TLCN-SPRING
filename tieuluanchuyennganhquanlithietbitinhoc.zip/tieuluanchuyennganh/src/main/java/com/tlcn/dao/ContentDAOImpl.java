package com.tlcn.dao;

import java.io.Serializable;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tlcn.model.Content;


@Repository
public class ContentDAOImpl implements ContentDAO {

	@Autowired
	private SessionFactory sessionFactory;

	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	@SuppressWarnings("unchecked")
	public List<Content> getAll() {
		Session session = getCurrentSession();
		Query query=session.createQuery("from Content");
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<Content> getContent_chuaduyet(){
		Session session = getCurrentSession();
		String check ="chuaduyet";
		Query query=session.createQuery("from Content as h where "
				+ "h.trangthai= :check");
		query.setParameter("check",check);
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<Content> getContent_daduyet(){
		Session session = getCurrentSession();
		String check ="daduyet";
		Query query=session.createQuery("from Content as h where "
				+ "h.trangthai= :check");
		query.setParameter("check",check);
		return query.list();
	}
	
	public void addContent(Content content){
		Session session = getCurrentSession();
		String hql ="insert into content (tendenghi, tenthietbi, soluong, ngaydenghi, nguoidenghi, noidung)"
				+ " values (?,?,?,?,?,?)";
		Query query = session.createSQLQuery(hql);
		String formatted = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date(System.currentTimeMillis()));
		query.setParameter(0, content.getTendenghi());
		query.setParameter(1, content.getTenthietbi());
		query.setParameter(2, content.getSoluong());
		query.setParameter(3,formatted);
		query.setParameter(4, content.getNguoidenghi());
		query.setParameter(5, content.getNoidung());
		
		query.executeUpdate();
	}
	public void updateContent_pheduyet(Content content, String nguoipheduyet ) {
		Session session = getCurrentSession();
		Content contentToUpdate = (Content) session.get(Content.class, content.getId());
		String formatted = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date(System.currentTimeMillis()));
		contentToUpdate.setNguoipheduyet(nguoipheduyet);
		contentToUpdate.setTrangthai("daduyet");
		contentToUpdate.setNgaypheduyet(formatted);
		session.save(contentToUpdate);

	}
	
	public Content getContentByID(Serializable mahd) {
		Content cont = (Content) getCurrentSession().get(Content.class, mahd);
		return cont;
	}
	
}
