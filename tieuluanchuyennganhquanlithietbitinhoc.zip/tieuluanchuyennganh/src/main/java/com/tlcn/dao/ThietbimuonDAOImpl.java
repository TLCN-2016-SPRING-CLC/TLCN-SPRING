package com.tlcn.dao;

import java.io.Serializable;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tlcn.model.Content;
import com.tlcn.model.Thietbimuon;

@Repository
public class ThietbimuonDAOImpl implements ThietbimuonDAO {
	@Autowired
	private SessionFactory sessionFactory;

	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	@SuppressWarnings("unchecked")
	public List<Thietbimuon> getAlls() {
		Session session = getCurrentSession();
		Query query=session.createQuery("from Thietbimuon");
		return query.list();
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Thietbimuon> getThietbimuon_damuon(){
		Session session = getCurrentSession();
		String check ="damuon";
		Query query=session.createQuery("from Thietbimuon as h where "
				+ "h.trangthai= :check");
		query.setParameter("check",check);
		return query.list();
	}
	
	public void addThietbimuon(Thietbimuon thietbimuon){
		Session session = getCurrentSession();
		String hql ="insert into thietbimuon (tenthietbi, loaithietbi, tinhtrang, nguoimuon, ngaymuon)"
				+ " values (?,?,?,?,?)";
		Query query = session.createSQLQuery(hql);
		String formatted = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date(System.currentTimeMillis()));
		query.setParameter(0, thietbimuon.getTenthietbi());
		query.setParameter(1, thietbimuon.getLoaithietbi());
		query.setParameter(2, thietbimuon.getTinhtrang());
		query.setParameter(3, thietbimuon.getNguoimuon());
		query.setParameter(4,formatted);
		
		query.executeUpdate();
	}
	public void updateThietbimuon_muon(Thietbimuon thietbimuon, String nguoimuon ) {
		Session session = getCurrentSession();
		Thietbimuon contentToUpdate = (Thietbimuon) session.get(Thietbimuon.class, thietbimuon.getId());
		String formatted = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date(System.currentTimeMillis()));
		contentToUpdate.setNguoimuon(nguoimuon);
		contentToUpdate.setTrangthai("damuon");
		contentToUpdate.setNgaymuon(formatted);
		session.save(contentToUpdate);

	}
	
	public Thietbimuon getThietbimuonByID(Serializable mahd) {
		Thietbimuon tbm = (Thietbimuon) getCurrentSession().get(Thietbimuon.class, mahd);
		return tbm;
	}
	
}
