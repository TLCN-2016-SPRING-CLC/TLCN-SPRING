package com.tlcn.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "thietbimuon")
public class Thietbimuon implements Serializable{

	@Id
	@GeneratedValue
	@Column(name="id")
	private Integer id;
	
	@Column(name = "tenthietbi")
	private String tenthietbi;

	@Column(name = "loaithietbi")
	private String loaithietbi;
	
	@Column(name="tinhtrang")
	private String tinhtrang;
	
	@Column(name = "nguoimuon")
	private String nguoimuon;

	@Column(name = "ngaymuon")
	private String ngaymuon;

	@Column(name = "trangthai")
	private String trangthai;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTenthietbi() {
		return tenthietbi;
	}

	public void setTenthietbi(String tenthietbi) {
		this.tenthietbi = tenthietbi;
	}

	public String getLoaithietbi() {
		return loaithietbi;
	}

	public void setLoaithietbi(String loaithietbi) {
		this.loaithietbi = loaithietbi;
	}

	public String getTinhtrang() {
		return tinhtrang;
	}

	public void setTinhtrang(String tinhtrang) {
		this.tinhtrang = tinhtrang;
	}

	public String getNguoimuon() {
		return nguoimuon;
	}

	public void setNguoimuon(String nguoimuon) {
		this.nguoimuon = nguoimuon;
	}

	public String getNgaymuon() {
		return ngaymuon;
	}

	public void setNgaymuon(String ngaymuon) {
		this.ngaymuon = ngaymuon;
	}
	
	public String getTrangthai() {
		return trangthai;
	}

	public void setTrangthai(String trangthai) {
		this.trangthai = trangthai;
	}

	
	
}
