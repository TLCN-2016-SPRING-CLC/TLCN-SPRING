package com.tlcn.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "content")
public class Content implements Serializable {

	@Id
	@GeneratedValue
	@Column(name="id")
	private Integer id;

	@Column(name = "tendenghi")
	private String tendenghi;

	@Column(name = "tenthietbi")
	private String tenthietbi;

	@Column(name = "soluong")
	private Integer soluong;

	@Column(name = "nguoidenghi")
	private String nguoidenghi;

	@Column(name = "noidung")
	private String noidung;

	@Column(name = "trangthai")
	private String trangthai;

	@Column(name = "ngaydenghi")
	private String ngaydenghi;

	@Column(name = "ngaypheduyet")
	private String ngaypheduyet;
	
	@Column(name = "nguoipheduyet")
	private String nguoipheduyet;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTendenghi() {
		return tendenghi;
	}

	public void setTendenghi(String tendenghi) {
		this.tendenghi = tendenghi;
	}

	public String getTenthietbi() {
		return tenthietbi;
	}

	public void setTenthietbi(String tenthietbi) {
		this.tenthietbi = tenthietbi;
	}

	public Integer getSoluong() {
		return soluong;
	}

	public void setSoluong(Integer soluong) {
		this.soluong = soluong;
	}

	public String getNguoidenghi() {
		return nguoidenghi;
	}

	public void setNguoidenghi(String nguoidenghi) {
		this.nguoidenghi = nguoidenghi;
	}

	public String getNoidung() {
		return noidung;
	}

	public void setNoidung(String noidung) {
		this.noidung = noidung;
	}

	public String getTrangthai() {
		return trangthai;
	}

	public void setTrangthai(String trangthai) {
		this.trangthai = trangthai;
	}

	public String getNgaydenghi() {
		return ngaydenghi;
	}

	public void setNgaydenghi(String ngaydenghi) {
		this.ngaydenghi = ngaydenghi;
	}

	public String getNgaypheduyet() {
		return ngaypheduyet;
	}

	public void setNgaypheduyet(String ngaypheduyet) {
		this.ngaypheduyet = ngaypheduyet;
	}
	
	public String getNguoipheduyet() {
		return nguoipheduyet;
	}

	public void setNguoipheduyet(String nguoipheduyet) {
		this.nguoipheduyet = nguoipheduyet;
	}

	
}