package com.tlcn.service;
import java.io.Serializable;
import java.util.List;

import com.tlcn.model.Content;

public interface ContentService {
	
	public List<Content> getAll();
	public List<Content> getContent_chuaduyet();
	public List<Content> getContent_daduyet();
	public void addContent(Content content);
	public Content getContentByID(Serializable mahd);
	public void updateContent_pheduyet(Content content, String nguoipheduyet );
}
