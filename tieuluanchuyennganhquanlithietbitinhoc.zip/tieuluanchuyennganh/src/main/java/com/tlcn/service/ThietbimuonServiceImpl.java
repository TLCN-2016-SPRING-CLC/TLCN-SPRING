package com.tlcn.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tlcn.dao.ThietbimuonDAO;
import com.tlcn.model.Thietbimuon;


@Service("thietbimuonService")
@Transactional
public class ThietbimuonServiceImpl implements ThietbimuonService{

	@Autowired
	private ThietbimuonDAO thietbimuonDAO;
	
	public List<Thietbimuon> getAlls(){
		return thietbimuonDAO.getAlls();
	}
	public List<Thietbimuon> getThietbimuon_damuon()
	{
		return thietbimuonDAO.getThietbimuon_damuon();
	}
	public void addThietbimuon(Thietbimuon thietbimuon)
	{
		thietbimuonDAO.addThietbimuon(thietbimuon);
	}
	public Thietbimuon getThietbimuonByID(Serializable mahd)
	{
		return thietbimuonDAO.getThietbimuonByID(mahd);
	}
	public void updateThietbimuon_muon(Thietbimuon thietbimuon, String nguoimuon )
	{
		thietbimuonDAO.updateThietbimuon_muon(thietbimuon, nguoimuon);
	}
	
}
