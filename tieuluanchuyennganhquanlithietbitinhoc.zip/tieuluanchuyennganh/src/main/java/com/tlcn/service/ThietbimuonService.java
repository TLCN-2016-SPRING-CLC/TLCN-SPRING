package com.tlcn.service;

import java.io.Serializable;
import java.util.List;

import com.tlcn.model.Thietbimuon;


public interface ThietbimuonService {

	public List<Thietbimuon> getAlls();
	public List<Thietbimuon> getThietbimuon_damuon();
	public void addThietbimuon(Thietbimuon thietbimuon);
	public Thietbimuon getThietbimuonByID(Serializable mahd);
	public void updateThietbimuon_muon(Thietbimuon thietbimuon, String nguoimuon );
}
