package com.doan.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.doan.model.HoatDong;
import com.doan.service.HoatDongService;

@Controller
public class LinkController {
	
	@Autowired
	private HoatDongService hoatdongService;
	
	@RequestMapping(value = { "/", "/index" } )
	public ModelAndView mainPage(HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("home");
		session.setAttribute("mssv",null );
		session.setAttribute("role",null );
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
		modelAndView.addObject("hoatdongs", hoatdongs);
		List<HoatDong> hoatdongsoccur = hoatdongService.getHoatDongsoccuring();
		modelAndView.addObject("hoatdongsoccur", hoatdongsoccur);
		
		return modelAndView;
	}
	@RequestMapping(value = { "/ketqua" }, method=RequestMethod.POST)
	public ModelAndView resultPage(HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView("ketquatimkiem");

		List<HoatDong> hoatdongs = hoatdongService.getHoatDongbyName(request.getParameter("key"));
		modelAndView.addObject("HoatDongTimThay", hoatdongs);
		
		return modelAndView;
	}
	
}
