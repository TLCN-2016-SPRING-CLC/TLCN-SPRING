package com.doan.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.doan.model.BanGiamHieu;
import com.doan.model.HoatDong;
import com.doan.service.BanGiamHieuService;
import com.doan.service.HoatDongService;

import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

@Controller
@RequestMapping(value="/bangiamhieu")
public class BanGiamHieuController {
	@Autowired
	private BanGiamHieuService bangiamhieuService;
	@Resource(name="hoatDongService")
	private HoatDongService hoatdongService;

	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginPage(Model model) 
	{
		model.addAttribute("bangiamhieu", new BanGiamHieu());
		return "login_BGH";
	}

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView doLoginPage(HttpSession session, @ModelAttribute @Valid BanGiamHieu bangiamhieu, BindingResult result, Model model) 
	{
		ModelAndView modelAndView=null;
		if(!result.hasFieldErrors()) 
		{
			if(!bangiamhieuService.checkLogin(bangiamhieu)) 
			{
				modelAndView = new ModelAndView("error_BGH");
				model.addAttribute("bangiamhieu", new BanGiamHieu());
			} 
			else 
			{
				session.setAttribute("MEMBER", bangiamhieu.getEmail());//add sesion 
				List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
				model.addAttribute("hoatdongsdapheduyet", hoatdongs);
				model.addAttribute("email", bangiamhieu.getEmail());
				modelAndView = new ModelAndView("home_BGH");
			}
		}
		else{
			modelAndView = new ModelAndView("login_BGH");
			model.addAttribute("bangiamhieu", new BanGiamHieu());
		}
		return modelAndView;
	}
	@RequestMapping("/DaPheDuyet")
	public String ShowChecked(Model model) 
	{
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongspheduyet();
		model.addAttribute("hoatdongsdapheduyet", hoatdongs);
		return "home_BGH";
	}
	@RequestMapping("/ChuaPheDuyet/{id}")
	public String ShowUnChecked(HttpServletRequest request, Model model, @PathVariable String id) 
	{
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongschuapheduyet();
		model.addAttribute("hoatdongschuapheduyet", hoatdongs);
		model.addAttribute("email", id);
		return "home_BGH_ChuaPheDuyet";
	}
	@RequestMapping(value="{email}/PheDuyetHoatDong", method=RequestMethod.GET)
	public ModelAndView showHoatDong(@RequestParam("id") Integer id, @PathVariable String email) {
		ModelAndView modelAndView = new ModelAndView("pheduyethoatdong");
		modelAndView.addObject("email", email);
		HoatDong hoatdongs = hoatdongService.getHoatDongByID(id);
		modelAndView.addObject("hoatdongAttribute", hoatdongs);
		return modelAndView;
	}
	@RequestMapping(value="{email}/PheDuyetHoatDong",params={"pheduyet"}, method = RequestMethod.POST)
	public String pheduyet(@RequestParam("id") Integer id, @ModelAttribute("hoatdongAttribute") HoatDong hoatdong, 
			ModelMap model, @PathVariable String email) {
		//int MaHD=Integer.parseInt(request.getParameter("mahd")); 
		//int daduyet=1;
		//String ykien=request.getParameter("ykien");
		BanGiamHieu bgh = new BanGiamHieu();
		bgh.setEmail(email);
		hoatdong.setMahd(id);
		//hoatdong.setNguoipheduyet(email);
		//hoatdong.setDaduyet(1);
		hoatdongService.updateHoatDong_pheduyet(hoatdong,bgh);

		List<HoatDong> hoatdongs = hoatdongService.getHoatDongspheduyet();
		model.addAttribute("hoatdongsdapheduyet", hoatdongs);
		return "home_BGH";
	}
	@RequestMapping(value="{email}/PheDuyetHoatDong",params={"dexuat"}, method = RequestMethod.POST)
	public String dexuat(@RequestParam("id") Integer id, @ModelAttribute("hoatdongAttribute") HoatDong hoatdong, 
			ModelMap model, @PathVariable String email) {
		BanGiamHieu bgh = new BanGiamHieu();
		bgh.setEmail(email);
		hoatdong.setMahd(id);
		hoatdong.setYkiendexuat(hoatdong.getYkiendexuat());
		hoatdongService.updateHoatDong_dexuat(hoatdong, bgh);

		List<HoatDong> hoatdongs = hoatdongService.getHoatDongschuapheduyet();
		model.addAttribute("hoatdongschuapheduyet", hoatdongs);
		return "home_BGH_ChuaPheDuyet";
	}
}