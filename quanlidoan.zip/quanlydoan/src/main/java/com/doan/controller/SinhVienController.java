package com.doan.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.doan.model.SinhVien;
import com.doan.model.Team;
import com.doan.model.BanGiamHieu;
import com.doan.model.HoatDong;
import com.doan.service.SinhVienService;
import com.doan.service.ThamGiaService;
import com.doan.service.HoatDongService;

@Controller
@RequestMapping(value="/sinhvien")
public class SinhVienController {
	@Autowired
	private SinhVienService sinhvienService;
	@Autowired
	private HoatDongService hoatdongService;
	@Autowired
	private ThamGiaService thamgiaService;

	@RequestMapping(value="/sv/dangxuat")
	public String logout(ModelMap model) throws Exception
	{
		sinhvienService.closesession();
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
		model.addAttribute("hoatdongs", hoatdongs);
		List<HoatDong> hoatdongsoccur = hoatdongService.getHoatDongsoccuring();
		model.addAttribute("hoatdongsoccur", hoatdongsoccur);
		return "home";
	}

	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginPage(Model model) 
	{
		model.addAttribute("sinhvien", new SinhVien());
		return "login_SV";
	}

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView doLoginPage(HttpServletRequest request, HttpSession session, @ModelAttribute @Valid SinhVien sinhvien, BindingResult result, Model model) 
	{
		ModelAndView modelAndView=null;
		int btv=0;
		String role=request.getParameter("role");
		if(role.equals("doanvien"))
		{
			btv=0;
		}
		else
		{
			btv=1;
		}
		if(!result.hasFieldErrors()) 
		{
			if(!sinhvienService.checkLogin(sinhvien,btv)) 
			{
				modelAndView = new ModelAndView("error_SV");
				model.addAttribute("sinhvien", new SinhVien());
			} 
			else 
			{
				if(btv==1)
				{
					session.setAttribute("mssv", sinhvien.getMssv());//add sesion 
					session.setAttribute("role", btv);//add sesion 
					List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
					model.addAttribute("hoatdongs", hoatdongs);
					List<HoatDong> hoatdongsoccur = hoatdongService.getHoatDongsoccuring();
					model.addAttribute("hoatdongsoccur", hoatdongsoccur);
					modelAndView = new ModelAndView("home_BTV");
				}
				else{
					session.setAttribute("mssv", sinhvien.getMssv());
					session.setAttribute("role", btv);
					List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
					model.addAttribute("hoatdongs", hoatdongs);
					List<HoatDong> hoatdongsoccur = hoatdongService.getHoatDongsoccuring();
					model.addAttribute("hoatdongsoccur", hoatdongsoccur);
					modelAndView = new ModelAndView("home_DV");
				}

			}
		}
		else{
			modelAndView = new ModelAndView("login_SV");
			model.addAttribute("sinhvien", new SinhVien());
		}
		return modelAndView;
	}
	@RequestMapping(value="{mssv}/btv/{role}/quanlyhoatdongdapheduyet")
	public String QuanLyHoatDong_DaPheDuyet(Model model,@PathVariable String mssv
			,@PathVariable int role, HttpSession session) 
	{
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
		model.addAttribute("hoatdongs", hoatdongs);
		return "quanlyhoatdong_dapheduyet";
	}
	@RequestMapping(value="{mssv}/btv/{role}/quanlyhoatdongchuapheduyet")
	public String QuanLyHoatDong_ChuaPheDuyet(Model model,@PathVariable String mssv
			,@PathVariable int role, HttpSession session) 
	{
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongschuapheduyet();
		model.addAttribute("hoatdongs", hoatdongs);
		return "quanlyhoatdong_chuapheduyet";
	}
	@RequestMapping(value="/{role}/btv/{mssv}/themhoatdong", method=RequestMethod.GET)
	public ModelAndView ThemHoatDong(HttpSession session, @PathVariable int mssv, @PathVariable int role) 
	{
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		ModelAndView modelAndView = new ModelAndView("themhoatdong");
		modelAndView.addObject("hoatdong", new HoatDong());
		modelAndView.addObject("ID", mssv);
		return modelAndView;
	}
	@RequestMapping(value="/{role}/btv/{mssv}/themhoatdong", method=RequestMethod.POST)
	public ModelAndView addingTeam(HttpSession session, @ModelAttribute HoatDong hoatdong, @PathVariable int mssv, @PathVariable int role) {

		ModelAndView modelAndView = new ModelAndView("quanlyhoatdong_chuapheduyet");
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		HoatDong them = new HoatDong();
		them.setNguoixaydung(mssv);
		them.setTenhd(hoatdong.getTenhd());
		them.setThoigian(hoatdong.getThoigian());
		them.setDiadiem(hoatdong.getDiadiem());
		them.setNoidung(hoatdong.getNoidung());
		them.setSoluong(hoatdong.getSoluong());
		them.setDrl(hoatdong.getDrl());

		hoatdongService.addHoatDong(them);

		//String message = "Team was successfully added.";
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongschuapheduyet();
		modelAndView.addObject("hoatdongs", hoatdongs);

		return modelAndView;
	}

	@RequestMapping(value="/{role}/btv/{mssv}/xoahoatdong_daduyet/{id}", method=RequestMethod.GET)
	public ModelAndView deleteHoatDong_checked(HttpSession session, @PathVariable Integer id, @PathVariable Integer mssv, @PathVariable Integer role) {

		ModelAndView modelAndView = new ModelAndView("xoahoatdong_dapheduyet");
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongspheduyet(id);
		modelAndView.addObject("XoaHoatDong_DaDuyet", hoatdongs);

		return modelAndView;
	}
	@RequestMapping(value="/{role}/btv/{mssv}/xoahoatdong_daduyet/{id}", method=RequestMethod.POST)
	public ModelAndView dodeleteHoatDong_checked(HttpSession session,@PathVariable Integer id
			, @PathVariable Integer mssv, @PathVariable Integer role) {

		ModelAndView modelAndView = new ModelAndView("quanlyhoatdong_dapheduyet");
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		hoatdongService.deleteHoatDong(id);
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongspheduyet();
		modelAndView.addObject("hoatdongs", hoatdongs);

		return modelAndView;
	}
	@RequestMapping(value="/{role}/btv/{mssv}/xoahoatdong_chuaduyet/{id}", method=RequestMethod.GET)
	public ModelAndView deleteHoatDong_unchecked(HttpSession session,@PathVariable Integer id
			, @PathVariable Integer mssv, @PathVariable Integer role) {

		ModelAndView modelAndView = new ModelAndView("xoahoatdong_chuapheduyet");
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		HoatDong hoatdongs = hoatdongService.getHoatDongByID(id);
		modelAndView.addObject("XoaHoatDong_ChuaDuyet", hoatdongs);

		return modelAndView;
	}
	@RequestMapping(value="/{role}/btv/{mssv}/xoahoatdong_chuaduyet/{id}", method=RequestMethod.POST)
	public ModelAndView dodeleteHoatDong_unchecked(HttpSession session,@PathVariable Integer id
			, @PathVariable Integer mssv, @PathVariable Integer role) {
		ModelAndView modelAndView = new ModelAndView("quanlyhoatdong_chuapheduyet");
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		hoatdongService.deleteHoatDong(id);
		//String message = "Team was successfully deleted.";
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongschuapheduyet();
		modelAndView.addObject("hoatdongs", hoatdongs);
		return modelAndView;
	}
	@RequestMapping(value="/{role}/btv/{mssv}/CapNhatHoatDong", method=RequestMethod.GET)
	public ModelAndView updateHoatDong(@RequestParam("id") Integer id,HttpSession session,
			@PathVariable Integer mssv, @PathVariable Integer role) {
		ModelAndView modelAndView = new ModelAndView("capnhathoatdong");
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		HoatDong hoatdongs = hoatdongService.getHoatDongByID(id);
		modelAndView.addObject("hoatdongAttribute", hoatdongs);
		return modelAndView;
	}
	@RequestMapping(value="/{role}/btv/{mssv}/CapNhatHoatDong", method = RequestMethod.POST)
	public ModelAndView pheduyet(@RequestParam("id") Integer id, @ModelAttribute("hoatdongAttribute") HoatDong hoatdong,
			HttpSession session, @PathVariable Integer mssv, @PathVariable Integer role) {
		ModelAndView modelAndView = new ModelAndView("quanlyhoatdong_chuapheduyet");
		hoatdong.setMahd(id);
		hoatdongService.updateHoatDong(hoatdong);
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongschuapheduyet();
		modelAndView.addObject("hoatdongs", hoatdongs);
		return modelAndView ;
	}
	@RequestMapping(value="/{role}/DiemRenLuyen/{mssv}")
	public String DiemRenLuyen(HttpSession session, ModelMap model, 
			@PathVariable String mssv, @PathVariable int role) throws Exception
	{
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		try{
			int id  = Integer.parseInt(mssv);
			List hoatdongs = hoatdongService.getHoatDongsdathamgia(id);

			model.addAttribute("DiemRenLuyen", hoatdongs);

		}
		catch (NumberFormatException e) 
		{
			System.out.println("Error");
		}
		return "diemrenluyen";
	}

	@RequestMapping(value="/{role}/DiemDanh/{mssv}")
	public String DiemDanh(HttpSession session, ModelMap model, 
			@PathVariable String mssv, @PathVariable int role) throws Exception
	{
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
		model.addAttribute("hoatdongs", hoatdongs);
		return "diemdanhsinhvienthamgia";
	}
	@RequestMapping(value="/{role}/btv/{mssv}/danhsachsinhvien/{id}", method=RequestMethod.GET)
	public ModelAndView xemdanhsachtg(HttpSession session,@PathVariable Integer id
			, @PathVariable Integer mssv, @PathVariable Integer role) {

		ModelAndView modelAndView = new ModelAndView("danhsachsinhvienthamgia");
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		List sinhviens = thamgiaService.getHoatDongsdathamgia(id);
		modelAndView.addObject("danhsachsv", sinhviens);

		return modelAndView;
	}
	@RequestMapping(value="/{role}/btv/{mssv}/danhsachsinhvien/{id}/{mahd}", method=RequestMethod.POST)
	public ModelAndView doxemdanhsachtg(HttpServletRequest request, HttpSession session,@PathVariable Integer id,@PathVariable Integer mahd
			, @PathVariable Integer mssv, @PathVariable Integer role) {
		ModelAndView modelAndView = new ModelAndView("danhsachsinhvienthamgia");
			session.setAttribute("mssv", mssv);
			session.setAttribute("role", role);
			thamgiaService.xacnhanthamgia(id, mahd);
		
		List sinhviens = thamgiaService.getHoatDongsdathamgia(mahd);
		modelAndView.addObject("danhsachsv", sinhviens);
		return modelAndView;
	}
	@RequestMapping(value="/ChiTietHoatDong/{id}", method=RequestMethod.GET)
	public ModelAndView showHoatDong(@PathVariable Integer id) {
		ModelAndView modelAndView = new ModelAndView("chitiethoatdong");

		HoatDong hoatdong = hoatdongService.getHoatDongByID(id);
		modelAndView.addObject("hoatdongAttribute", hoatdong);
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongbyId(id);
		modelAndView.addObject("ChiTietHoatDong", hoatdongs);

		return modelAndView;
	}
	@RequestMapping(value="/ChiTietHoatDong/{id}", method=RequestMethod.POST)
	public ModelAndView joinHoatDong(HttpServletRequest request, @PathVariable Integer id) {
		ModelAndView modelAndView = new ModelAndView("chitiethoatdong");

		int mahd=Integer.parseInt(request.getParameter("mahd"));  
		int masv=Integer.parseInt(request.getParameter("svtg")); 

		hoatdongService.addHoatDong_ThamGia(masv, mahd);
		String message = "Bạn đã đăng ký tham gia hoạt động này. Vui lòng tham gia đúng hẹn";
		modelAndView.addObject("message", message);

		return modelAndView;
	}
	@RequestMapping(value = { "{role}/ketqua/{mssv}" }, method=RequestMethod.POST)
	public ModelAndView resultPage(HttpServletRequest request, HttpSession session,@PathVariable String mssv
			,@PathVariable int role) {
		ModelAndView modelAndView = new ModelAndView("ketquatimkiem");

		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);

		List<HoatDong> hoatdongs = hoatdongService.getHoatDongbyName(request.getParameter("key"));
		modelAndView.addObject("HoatDongTimThay", hoatdongs);

		return modelAndView;
	}
	@RequestMapping(value = { "{role}/home/{mssv}" })
	public ModelAndView homePage(HttpServletRequest request, HttpSession session,@PathVariable String mssv,@PathVariable int role) {
		ModelAndView modelAndView=null;
		session.setAttribute("mssv", mssv);
		session.setAttribute("role", role);
		if(role==0)
		{
			modelAndView = new ModelAndView("home_DV");
		}
		else
		{
			modelAndView = new ModelAndView("home_BTV");
		}
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
		modelAndView.addObject("hoatdongs", hoatdongs);
		List<HoatDong> hoatdongsoccur = hoatdongService.getHoatDongsoccuring();
		modelAndView.addObject("hoatdongsoccur", hoatdongsoccur);

		return modelAndView;
	}
	@RequestMapping(value = { "/dangxuat" })
	public ModelAndView signOut(HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("home");
		session.setAttribute("mssv",null );
		session.setAttribute("role",null );
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
		modelAndView.addObject("hoatdongs", hoatdongs);
		List<HoatDong> hoatdongsoccur = hoatdongService.getHoatDongsoccuring();
		modelAndView.addObject("hoatdongsoccur", hoatdongsoccur);

		return modelAndView;
	}

}
