package com.doan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.doan.model.HoatDong;
import com.doan.service.HoatDongService;

@Controller
@RequestMapping(value="/hoatdong")
public class HoatDongController {
	
	@Autowired
	private HoatDongService hoatdongService;
	
	@RequestMapping(value="/list")
	public ModelAndView listOfHoatDongs() {
		ModelAndView modelAndView = new ModelAndView("home");

		List<HoatDong> hoatdongs = hoatdongService.getHoatDongs();
		modelAndView.addObject("hoatdongs", hoatdongs);

		return modelAndView;
	}
	
	/*@RequestMapping(value="/ChiTietHoatDong")
	public String showProducts(ModelMap model, 
			@RequestParam(value="mahd") Integer mahd) {	
		model.addAttribute("ChiTietHoatDong", hoatdongService.getHoatDongByID(mahd));
	return "chitiethoatdong";

	}*/
	@RequestMapping(value="/ChiTietHoatDong/{id}", method=RequestMethod.GET)
	public ModelAndView showHoatDong(@PathVariable Integer id) {
		ModelAndView modelAndView = new ModelAndView("chitiethoatdong");
		
		List<HoatDong> hoatdongs = hoatdongService.getHoatDongbyId(id);
		modelAndView.addObject("ChiTietHoatDong", hoatdongs);

		return modelAndView;
	}


}
