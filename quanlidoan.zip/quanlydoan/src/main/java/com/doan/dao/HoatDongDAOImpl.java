package com.doan.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.doan.model.BanGiamHieu;
import com.doan.model.HoatDong;

@Repository
public class HoatDongDAOImpl implements HoatDongDAO {

	@Autowired
	private SessionFactory sessionFactory;

	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	@SuppressWarnings("unchecked")
	public List<HoatDong> getHoatDongs() {
		Session session = getCurrentSession();
		Query query=session.createQuery("from HoatDong as h where "
				+ "h.daduyet= :duyet and h.thoigian >= CURRENT_TIMESTAMP() order by h.thoigian desc");
		query.setParameter("duyet", 1);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<HoatDong> getHoatDongsoccuring(){
		Session session = getCurrentSession();
		Query query=session.createQuery("from HoatDong as h where "
				+ "h.daduyet= :duyet and h.thoigian >= CURRENT_TIMESTAMP() order by (CURRENT_TIMESTAMP() - h.thoigian) desc");
		query.setParameter("duyet", 1);
		return query.list();
	}
	public List getHoatDongsdathamgia(int id){
		Session session = getCurrentSession();
		 String sql = "select t.hoatdongthamgia, h.tenhd, h.thoigian, h.drl, t.dathamgia "
		 		+ "from thamgia t, hoatdongs h where t.hoatdongthamgia = h.mahd and "
		 		+ "t.svthamgia= :id";
		 SQLQuery query = session.createSQLQuery(sql);
	     query.setParameter("id", id);
	     query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		//query.setParameter("id", id);
		//query.setParameter("done", 1);
		return query.list();
		
	}
	@SuppressWarnings("unchecked")
	public List<HoatDong> getHoatDongbyName(String name){
		Session session = getCurrentSession();
		Query query=session.createQuery("from HoatDong as h where "
				+ "h.daduyet= :duyet and h.tenhd like :keyword order by (CURRENT_TIMESTAMP() - h.thoigian) desc");
		query.setParameter("duyet", 1);
		//query.setParameter("ten", name);
		query.setParameter("keyword", "%" + name + "%");
		return query.list();
	}
	@SuppressWarnings("unchecked")
	public List<HoatDong> getHoatDongspheduyet(){
		Session session = getCurrentSession();
		Query query=session.createQuery("from HoatDong as h where "
				+ "h.daduyet= :duyet and h.thoigian >= CURRENT_TIMESTAMP() order by h.thoigian desc");
		query.setParameter("duyet", 1);
		return query.list();
	}
	@SuppressWarnings("unchecked")
	public List<HoatDong> getHoatDongspheduyet(Serializable mahd){
		Session session = getCurrentSession();
		Query query=session.createQuery("from HoatDong as h where "
				+ "h.daduyet= :duyet and h.mahd= :id");
		query.setParameter("duyet", 1);
		query.setParameter("id", mahd);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<HoatDong> getHoatDongschuapheduyet(){
		Session session = getCurrentSession();
		Query query=session.createQuery("from HoatDong as h where "
				+ "h.daduyet= :duyet and h.thoigian >= CURRENT_TIMESTAMP() order by h.thoigian desc");
		query.setParameter("duyet", 0);
		return query.list();
	}
	@SuppressWarnings("unchecked")
	public List<HoatDong> getHoatDongschuapheduyet(Serializable mahd){
		Session session = getCurrentSession();
		Query query=session.createQuery("from HoatDong as h where "
				+ "h.daduyet= :duyet and h.mahd= :id");
		query.setParameter("duyet", 0);
		query.setParameter("id", mahd);
		return query.list();
	}

	public HoatDong getHoatDongByID(Serializable mahd) {
		HoatDong hoatdong = (HoatDong) getCurrentSession().get(HoatDong.class, mahd);
		return hoatdong;
	}
	@SuppressWarnings("unchecked")
	public List<HoatDong> getHoatDongbyId(Serializable mahd){
		Session session = getCurrentSession();
		Query query=session.createQuery("from HoatDong as h where "
				+ "h.mahd= :id");
		query.setParameter("id", mahd);
		return query.list();
	}
	
	public void addHoatDong(HoatDong hoatdong){
		Session session = getCurrentSession();
		String hql ="insert into hoatdongs (nguoixaydung, tenhd, thoigian, soluong, diadiem, noidung, drl)"
				+ " values (?,?,?,?,?,?,?)";
		Query query = session.createSQLQuery(hql);
	
		query.setParameter(0, hoatdong.getNguoixaydung());
		query.setParameter(1, hoatdong.getTenhd());
		query.setParameter(2, hoatdong.getThoigian());
		query.setParameter(3, hoatdong.getSoluong());
		query.setParameter(4, hoatdong.getDiadiem());
		query.setParameter(5, hoatdong.getNoidung());
		query.setParameter(6, hoatdong.getDrl());
		
		query.executeUpdate();
	}
	public void addHoatDong_ThamGia (int svtg, int hdtg){
		Session session = getCurrentSession();
		String sql = "insert into thamgia (svthamgia, hoatdongthamgia)"
				+ " values (?,?)";
		Query query = session.createSQLQuery(sql);
		
		query.setParameter(0, svtg);
		query.setParameter(1, hdtg);
		
		query.executeUpdate();
	}
	public void deleteHoatDong(int id) {
		HoatDong hoatdong = getHoatDongByID(id);
		if (hoatdong != null)
			getCurrentSession().delete(hoatdong);
	}
	public void updateHoatDong(HoatDong hoatdong) {
		Session session = getCurrentSession();
		HoatDong hoatdongToUpdate = (HoatDong) session.get(HoatDong.class, hoatdong.getMahd());
		hoatdongToUpdate.setTenhd(hoatdong.getTenhd());
		hoatdongToUpdate.setSoluong(hoatdong.getSoluong());
		hoatdongToUpdate.setDrl(hoatdong.getDrl());
		hoatdongToUpdate.setDiadiem(hoatdong.getDiadiem());
		hoatdongToUpdate.setThoigian(hoatdong.getThoigian());
		hoatdongToUpdate.setNoidung(hoatdong.getNoidung());
		session.save(hoatdongToUpdate);

	}
	public void updateHoatDong_pheduyet(HoatDong hoatdong, BanGiamHieu bgh) {
		Session session = getCurrentSession();
		HoatDong hoatdongToUpdate = (HoatDong) session.get(HoatDong.class, hoatdong.getMahd());
		hoatdongToUpdate.setNguoipheduyet(bgh.getEmail());
		hoatdongToUpdate.setDaduyet(1);
		hoatdongToUpdate.setYkiendexuat(hoatdong.getYkiendexuat());
		session.save(hoatdongToUpdate);

	}
	public void updateHoatDong_dexuat(HoatDong hoatdong, BanGiamHieu bgh) {
		Session session = getCurrentSession();
		HoatDong hoatdongToUpdate = (HoatDong) session.get(HoatDong.class, hoatdong.getMahd());
		hoatdongToUpdate.setNguoipheduyet(bgh.getEmail());
		hoatdongToUpdate.setYkiendexuat(hoatdong.getYkiendexuat());
		session.save(hoatdongToUpdate);

	}
	
}
