package com.doan.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ThamGiaDAOImpl implements ThamGiaDAO{
	
	@Autowired
	private SessionFactory sessionFactory;

	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	public List getHoatDongsdathamgia(int id){
		Session session = getCurrentSession();
		 String sql = "select s.mssv, s.fullname, s.email, s.pass, s.phone, s.drlsinhvien, h.drl as drl, h.mahd as mahd, h.thoigian as thoigian "
		 		+ "from thamgia t, sinhviens s, hoatdongs h where t.dathamgia=0 and t.hoatdongthamgia = h.mahd and t.svthamgia = s.mssv and "
		 		+ "t.hoatdongthamgia= :id";
		 SQLQuery query = session.createSQLQuery(sql);
	     query.setParameter("id", id);
	     query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		return query.list();
		
	}

	public void xacnhanthamgia(int id, int mahd){
		Session session = getCurrentSession();
		 String sql = "update thamgia, sinhviens set "
		 		+ "dathamgia = 1 where "
		 		+ "svthamgia= :id and hoatdongthamgia= :mahd";
		 SQLQuery query = session.createSQLQuery(sql);
	     query.setParameter("id", id);
	     query.setParameter("mahd", mahd);
	     query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		 query.executeUpdate();
		
	}
}
