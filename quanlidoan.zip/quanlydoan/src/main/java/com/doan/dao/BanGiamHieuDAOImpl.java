package com.doan.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.doan.model.BanGiamHieu;
import com.doan.model.HoatDong;

@Repository
public class BanGiamHieuDAOImpl implements BanGiamHieuDAO {
	@Autowired
	private SessionFactory sessionFactory;

	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
	@SuppressWarnings("unchecked")
	public boolean checkLogin(BanGiamHieu bangiamhieu) {

		List<BanGiamHieu> users = new ArrayList<BanGiamHieu>();
		users = sessionFactory.getCurrentSession().createQuery("from BanGiamHieu where email=? and pass=?").setParameter(0, bangiamhieu.getEmail()).setParameter(1, bangiamhieu.getPass())
				.list();

		if (users.size() > 0) {
			return true;
		} else {
			return false;
		}

	}
	@SuppressWarnings("unchecked")
	public List<BanGiamHieu> getBanGiamHieuByemail(Serializable email){
		Session session = getCurrentSession();
		 Query query=session.createQuery("from BanGiamHieu as h where "
					+ "h.email= :email");
		 query.setParameter("email", email);
		 return query.list();
	}
	public BanGiamHieu getBanGiamHieuByEmail(String email){
		 Session session = sessionFactory.getCurrentSession();
		   
		  // Retrieve existing person
		  // Create a Hibernate query (HQL)
		  Query query = session.createQuery("FROM BanGiamHieu as p LEFT JOIN FETCH p.hoatdong WHERE p.email='"+email+"'");
		   
		  return (BanGiamHieu) query.list();
	}
}
