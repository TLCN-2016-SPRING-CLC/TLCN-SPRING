package com.doan.dao;

import java.io.Serializable;
import java.util.List;

import com.doan.model.BanGiamHieu;
import com.doan.model.HoatDong;
import com.doan.model.Team;

public interface HoatDongDAO {
	
	public List<HoatDong> getHoatDongs();
	public List<HoatDong> getHoatDongsoccuring();
	public List getHoatDongsdathamgia(int id);
	public List<HoatDong> getHoatDongbyName(String name);
	public List<HoatDong> getHoatDongspheduyet();
	public List<HoatDong> getHoatDongspheduyet(Serializable mahd);
	public List<HoatDong> getHoatDongschuapheduyet();
	public List<HoatDong> getHoatDongschuapheduyet(Serializable mahd);
	public HoatDong getHoatDongByID(Serializable mahd);
	public List<HoatDong> getHoatDongbyId(Serializable mahd);
	
	public void addHoatDong(HoatDong hoatdong);
	public void addHoatDong_ThamGia (int svtg, int hdtg);
	public void updateHoatDong(HoatDong hoatdong);
	public void updateHoatDong_pheduyet(HoatDong hoatdong, BanGiamHieu bgh);
	public void updateHoatDong_dexuat(HoatDong hoatdong, BanGiamHieu bgh);
	public void deleteHoatDong(int id);
}

