package com.doan.dao;

import java.io.Serializable;
import java.util.List;

import com.doan.model.BanGiamHieu;
import com.doan.model.HoatDong;

public interface BanGiamHieuDAO {
	public boolean checkLogin(BanGiamHieu bangiamhieu);
	public List<BanGiamHieu> getBanGiamHieuByemail(Serializable email);
	public BanGiamHieu getBanGiamHieuByEmail(String email);
}
