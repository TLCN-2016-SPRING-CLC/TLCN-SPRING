package com.doan.dao;

import java.util.List;

public interface ThamGiaDAO {
	public List getHoatDongsdathamgia(int id);
	public void xacnhanthamgia(int id, int mahd);
}
