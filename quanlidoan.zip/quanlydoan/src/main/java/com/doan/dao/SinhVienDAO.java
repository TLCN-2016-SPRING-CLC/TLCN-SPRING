package com.doan.dao;

import com.doan.model.SinhVien;

public interface SinhVienDAO {
	public boolean checkLogin(SinhVien sinhvien, int role);
	public void closesession();
}
