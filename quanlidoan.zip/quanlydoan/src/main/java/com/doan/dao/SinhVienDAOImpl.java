package com.doan.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.doan.model.SinhVien;
@Repository
public class SinhVienDAOImpl implements SinhVienDAO {
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	public boolean checkLogin(SinhVien sinhvien, int role) {

		List<SinhVien> users = new ArrayList<SinhVien>();
		
		users = sessionFactory.getCurrentSession().createQuery("from SinhVien where mssv=? and pass=? and banthuongvu=?").
				setParameter(0, sinhvien.getMssv()).setParameter(1, sinhvien.getPass()).setParameter(2, role)
				.list();

		if (users.size() > 0) {
			return true;
		} else {
			return false;
		}

	}
	public void closesession(){
		sessionFactory.getCurrentSession().close();
	}
}
