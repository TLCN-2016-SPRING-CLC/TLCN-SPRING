package com.doan.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "hoatdongs", uniqueConstraints = { @UniqueConstraint(columnNames = { "mahd" }),
		@UniqueConstraint(columnNames = { "nguoixaydung" }), @UniqueConstraint(columnNames = { "nguoipheduyet" })})
public class HoatDong implements Serializable {
	@Id
	@GeneratedValue
	@Column(name="mahd")
	private Integer mahd;

	@Column(name = "nguoipheduyet")
	private String nguoipheduyet;

	@Column(name = "nguoixaydung")
	private Integer nguoixaydung;

	@Column(name = "tenhd")
	private String tenhd;

	@Column(name = "daduyet")
	private Integer daduyet;

	@Column(name = "thoigian")
	private String thoigian;

	@Column(name = "soluong")
	private Integer soluong;

	@Column(name = "diadiem")
	private String diadiem;

	@Column(name = "noidung")
	private String noidung;

	@Column(name = "hinhanh")
	private String hinhanh;

	@Column(name = "ykiendexuat")
	private String ykiendexuat;

	@Column(name = "drl")
	private Integer drl;
	
	public HoatDong(){
		
	}

	public HoatDong(Integer mahd, String nguoipheduyet, Integer nguoixaydung, String tenhd, Integer daduyet, String thoigian, 
			Integer soluong, String diadiem, String noidung, String hinhanh, String ykiendexuat, Integer drl){
		this.mahd=mahd;
		this.nguoipheduyet=nguoipheduyet;
		this.nguoixaydung=nguoixaydung;
		this.tenhd=tenhd;
		this.daduyet=daduyet;
		this.thoigian=thoigian;
		this.soluong=soluong;
		this.diadiem=diadiem;
		this.noidung=noidung;
		this.hinhanh=hinhanh;
		this.ykiendexuat=ykiendexuat;
		this.drl=drl;
	}
	public Integer getMahd() {
		return mahd;
	}

	public void setMahd(Integer mahd) {
		this.mahd = mahd;
	}

	public String getTenhd() {
		return tenhd;
	}

	public void setTenhd(String tenhd) {
		this.tenhd = tenhd;
	}

	public String getNguoipheduyet() {
		return nguoipheduyet;
	}

	public void setNguoipheduyet(String nguoipheduyet) {
		this.nguoipheduyet = nguoipheduyet;
	}

	public Integer getNguoixaydung() {
		return nguoixaydung;
	}

	public void setNguoixaydung(Integer nguoixaydung) {
		this.nguoixaydung = nguoixaydung;
	}

	public Integer getDaduyet() {
		return daduyet;
	}

	public void setDaduyet(Integer daduyet) {
		this.daduyet = daduyet;
	}

	public String getThoigian() {
		return thoigian;
	}

	public void setThoigian(String thoigian) {
		this.thoigian = thoigian;
	}

	public Integer getSoluong() {
		return soluong;
	}

	public void setSoluong(Integer soluong) {
		this.soluong = soluong;
	}

	public String getDiadiem() {
		return diadiem;
	}

	public void setDiadiem(String diadiem) {
		this.diadiem = diadiem;
	}

	public String getNoidung() {
		return noidung;
	}

	public void setNoidung(String noidung) {
		this.noidung = noidung;
	}

	public String getHinhanh() {
		return hinhanh;
	}

	public void setHinhanh(String hinhanh) {
		this.hinhanh = hinhanh;
	}

	public String getYkiendexuat() {
		return ykiendexuat;
	}

	public void setYkiendexuat(String ykiendexuat) {
		this.ykiendexuat = ykiendexuat;
	}

	public Integer getDrl() {
		return drl;
	}

	public void setDrl(Integer drl) {
		this.drl = drl;
	}


}