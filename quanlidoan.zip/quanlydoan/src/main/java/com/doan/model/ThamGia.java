package com.doan.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "thamgia")
public class ThamGia {
	@Id
	@GeneratedValue
	private Integer svthamgia;

	private Integer hoatdongthamgia;

	private Integer dathamgia;

	@ManyToOne(fetch = FetchType.LAZY)
	private HoatDong hoatdong;

	@ManyToOne(fetch = FetchType.LAZY)
	private SinhVien sinhvien;
	
	
	public HoatDong getHoatdong() {
		return hoatdong;
	}

	public void setHoatdong(HoatDong hoatdong) {
		this.hoatdong = hoatdong;
	}

	public SinhVien getSinhvien() {
		return sinhvien;
	}

	public void setSinhvien(SinhVien sinhvien) {
		this.sinhvien = sinhvien;
	}

	public Integer getSvthamgia() {
		return svthamgia;
	}

	public void setSvthamgia(Integer svthamgia) {
		this.svthamgia = svthamgia;
	}

	public Integer getHoatdongthamgia() {
		return hoatdongthamgia;
	}

	public void setHoatdongthamgia(Integer hoatdongthamgia) {
		this.hoatdongthamgia = hoatdongthamgia;
	}

	public Integer getDathamgia() {
		return dathamgia;
	}

	public void setDathamgia(Integer dathamgia) {
		this.dathamgia = dathamgia;
	}

	
}
