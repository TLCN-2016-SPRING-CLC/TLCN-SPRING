package com.doan.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "sinhviens")
public class SinhVien {
	@Id
	@GeneratedValue
	private Integer mssv;

	private String fullname;

	private String email;

	private String pass;

	private String phone;

	private String image;

	private Integer banthuongvu;

	private Integer drlsinhvien;

	public Integer getMssv() {
		return mssv;
	}

	public void setMssv(Integer mssv) {
		this.mssv = mssv;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public Integer getBanthuongvu() {
		return banthuongvu;
	}

	public void setBanthuongvu(Integer banthuongvu) {
		this.banthuongvu = banthuongvu;
	}

	public Integer getDrlsinhvien() {
		return drlsinhvien;
	}

	public void setDrlsinhvien(Integer drlsinhvien) {
		this.drlsinhvien = drlsinhvien;
	}
	
	
}
