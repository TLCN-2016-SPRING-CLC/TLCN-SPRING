package com.doan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.doan.dao.SinhVienDAO;
import com.doan.model.SinhVien;

@Service
@Transactional
public class SinhVienServiceImpl implements SinhVienService{
	@Autowired
	private SinhVienDAO sinhvienDAO;
	
	public boolean checkLogin(SinhVien sinhvien, int role){
		return sinhvienDAO.checkLogin(sinhvien,role);
	}
	public void closesession(){
		sinhvienDAO.closesession();
	}

}
