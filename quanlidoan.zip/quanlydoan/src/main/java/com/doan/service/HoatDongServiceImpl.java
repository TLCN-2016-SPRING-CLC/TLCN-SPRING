package com.doan.service;
import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.doan.dao.HoatDongDAO;
import com.doan.model.BanGiamHieu;
import com.doan.model.HoatDong;

@Service("hoatDongService")
@Transactional
public class HoatDongServiceImpl implements HoatDongService {
	
	@Autowired
	private HoatDongDAO hoatdongDAO;
	
	public List<HoatDong> getHoatDongs() {
		return hoatdongDAO.getHoatDongs();
	}
	public List<HoatDong> getHoatDongsoccuring(){
		return hoatdongDAO.getHoatDongsoccuring();
	}
	public List getHoatDongsdathamgia(int id){
		return hoatdongDAO.getHoatDongsdathamgia(id);
	}
	public List<HoatDong> getHoatDongbyName(String name){
		return hoatdongDAO.getHoatDongbyName(name);
	}
	public List<HoatDong> getHoatDongspheduyet(){
		return hoatdongDAO.getHoatDongspheduyet();
	}
	public List<HoatDong> getHoatDongspheduyet(Serializable mahd){
		return hoatdongDAO.getHoatDongspheduyet(mahd);
	}
	public List<HoatDong> getHoatDongschuapheduyet(){
		return hoatdongDAO.getHoatDongschuapheduyet();
	}
	public List<HoatDong> getHoatDongschuapheduyet(Serializable mahd){
		return hoatdongDAO.getHoatDongschuapheduyet(mahd);
	}
	public List<HoatDong> getHoatDongbyId(Serializable mahd){
		return hoatdongDAO.getHoatDongbyId(mahd);
	}
	public HoatDong getHoatDongByID(Serializable mahd){
		return hoatdongDAO.getHoatDongByID(mahd);
	}
	public void addHoatDong(HoatDong hoatdong){
		hoatdongDAO.addHoatDong(hoatdong);
	}
	public void addHoatDong_ThamGia (int svtg, int hdtg){
		hoatdongDAO.addHoatDong_ThamGia(svtg, hdtg);
	}
	public void updateHoatDong_pheduyet(HoatDong hoatdong, BanGiamHieu bgh){
		hoatdongDAO.updateHoatDong_pheduyet(hoatdong, bgh);
	}
	public void updateHoatDong_dexuat(HoatDong hoatdong, BanGiamHieu bgh){
		hoatdongDAO.updateHoatDong_dexuat(hoatdong, bgh);
	}
	public void deleteHoatDong(int id){
		hoatdongDAO.deleteHoatDong(id);
	}
	public void updateHoatDong(HoatDong hoatdong){
		hoatdongDAO.updateHoatDong(hoatdong);
	}

}
