package com.doan.service;

import java.util.List;

public interface ThamGiaService {
	public List getHoatDongsdathamgia(int id);
	public void xacnhanthamgia(int id, int mahd);
}
