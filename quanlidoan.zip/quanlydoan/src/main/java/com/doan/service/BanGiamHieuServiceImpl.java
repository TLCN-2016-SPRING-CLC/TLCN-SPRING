package com.doan.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.doan.dao.BanGiamHieuDAO;
import com.doan.model.BanGiamHieu;

@Service
@Transactional
public class BanGiamHieuServiceImpl implements BanGiamHieuService {
	@Autowired
	private BanGiamHieuDAO bangiamhieuDAO;
	
	public boolean checkLogin(BanGiamHieu bangiamhieu){
		return bangiamhieuDAO.checkLogin(bangiamhieu);
	}
	public List<BanGiamHieu> getBanGiamHieuByemail(Serializable email){
		return bangiamhieuDAO.getBanGiamHieuByemail(email);
	}
	public BanGiamHieu getBanGiamHieuByEmail(String email){
		return bangiamhieuDAO.getBanGiamHieuByEmail(email);
	}
}
