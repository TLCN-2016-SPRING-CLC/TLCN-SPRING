package com.doan.service;

import java.io.Serializable;
import java.util.List;

import com.doan.model.BanGiamHieu;

public interface BanGiamHieuService {
	public boolean checkLogin(BanGiamHieu bangiamhieu);
	public List<BanGiamHieu> getBanGiamHieuByemail(Serializable email);
	public BanGiamHieu getBanGiamHieuByEmail(String email);
}
