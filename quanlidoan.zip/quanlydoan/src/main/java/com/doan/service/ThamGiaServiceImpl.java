package com.doan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.doan.dao.ThamGiaDAO;
@Service
@Transactional
public class ThamGiaServiceImpl implements ThamGiaService {
	@Autowired
	private ThamGiaDAO thamgiaDAO;
	
	public List getHoatDongsdathamgia(int id){
		return thamgiaDAO.getHoatDongsdathamgia(id);
	}
	public void xacnhanthamgia(int id, int mahd){
		thamgiaDAO.xacnhanthamgia(id, mahd);
	}
}
