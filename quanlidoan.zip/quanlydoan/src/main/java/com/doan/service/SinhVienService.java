package com.doan.service;

import com.doan.model.SinhVien;

public interface SinhVienService {
	public boolean checkLogin(SinhVien sinhvien, int role);
	public void closesession();
}
