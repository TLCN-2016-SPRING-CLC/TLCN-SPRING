package com.websystique.springmvc.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.websystique.springmvc.dao.UserDAO;
import com.websystique.springmvc.model.User;

@Service("userService")
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDAO userDAO;
	
	@Override
	@Transactional
	public User findById(int id) {
		return this.userDAO.findById(id);
	}
	@Override
	@Transactional
	public User findByName(String name) {
		return this.userDAO.findByName(name);
	}
	@Override
	@Transactional
	public void saveUser(User user) {
		this.userDAO.saveUser(user);		
	}
	@Override
	@Transactional
	public void updateUser(User user) {
		this.userDAO.updateUser(user);
    }
	@Override
	@Transactional
	public void deleteUserById(int id) {
		this.userDAO.deleteUserById(id);
	}
	@Override
	@Transactional
	public List<User> findAllUsers() {
		return this.userDAO.findAllUsers();
	}
	@Override
	@Transactional
	public void deleteAllUsers() {
		this.userDAO.deleteAllUsers();
	}
}



