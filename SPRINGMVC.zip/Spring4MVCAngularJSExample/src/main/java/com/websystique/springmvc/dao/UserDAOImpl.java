package com.websystique.springmvc.dao;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.websystique.springmvc.model.User;

@Repository("userDao")
public class UserDAOImpl implements UserDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(UserDAOImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}

	@Override
	@Transactional
	public User findById(int id) {
		Session session = this.sessionFactory.getCurrentSession();		
		User user = (User) session.load(User.class, new Integer(id));
		logger.info("User loaded successfully, User details="+user);
		return user;
	}
	@Override
	@Transactional
	public User findByName(String name){
		Session session = this.sessionFactory.getCurrentSession();	
		User user= (User) session.get(User.class,name);
		return user;
	}

	@Override
	@Transactional
	public void saveUser(User user) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(user);
		logger.info("User saved successfully, User Details="+user);
	}

	@Override
	@Transactional
	public void updateUser(User user) {
		Session session = this.sessionFactory.getCurrentSession();
		session.update(user);
		logger.info("User updated successfully, User Details="+user);
	}
	@Override
	@Transactional
	public void deleteUserById(int id) {
		Session session = this.sessionFactory.getCurrentSession();
		User user = (User) session.load(User.class, new Integer(id));
		if(null != user){
			session.delete(user);
		}
		logger.info("User deleted successfully, user details="+user);
	}
	
	@SuppressWarnings({ "unchecked" })
	@Transactional
	public List<User>  findAllUsers() {
		Session session = this.sessionFactory.getCurrentSession();
		List<User> findAllUsers = session.createQuery("from User").list();
		for(User user : findAllUsers){
			logger.info("User List::"+user);
		}
		return findAllUsers;
	}
	
	@Transactional
	@Override
	public void deleteAllUsers(){

		Session session = this.sessionFactory.getCurrentSession();	
		String sql =  "DELETE FROM User ";
		Query query = session.createSQLQuery(sql);
		query.executeUpdate();
	}
	
}
