package com.tlcn.service;
import com.tlcn.model.User;

public interface UserService {
	
	public boolean checkLogin(User user, int role);
}
