package com.tlcn.service;
import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tlcn.dao.ContentDAO;
import com.tlcn.model.Content;

@Service("contentService")
@Transactional
public class ContentServiceImpl implements ContentService {
	
	@Autowired
	private ContentDAO contentDAO;
	
	public List<Content> getAll(){
		return contentDAO.getAll();
	}
	public List<Content> getContent_chuaduyet(){
		return contentDAO.getContent_chuaduyet();
	}
	public List<Content> getContent_daduyet(){
		return contentDAO.getContent_daduyet();
	}
	public void addContent(Content content)
	{
		contentDAO.addContent(content);
	}
	public Content getContentByID(Serializable mahd)
	{
		return contentDAO.getContentByID(mahd);
	}
	public void updateContent_pheduyet(Content content, String nguoipheduyet )
	{
		contentDAO.updateContent_pheduyet(content, nguoipheduyet);
	}
}
