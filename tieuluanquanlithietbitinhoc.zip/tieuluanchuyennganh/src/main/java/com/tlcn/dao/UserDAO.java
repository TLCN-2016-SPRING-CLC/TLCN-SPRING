package com.tlcn.dao;


import com.tlcn.model.User;

public interface UserDAO {
	
	public boolean checkLogin(User user, int role);
	
}

