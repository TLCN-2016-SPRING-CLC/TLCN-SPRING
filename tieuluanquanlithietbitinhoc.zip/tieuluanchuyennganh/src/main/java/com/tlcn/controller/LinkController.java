package com.tlcn.controller;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.tlcn.model.Content;
import com.tlcn.model.User;
import com.tlcn.service.ContentService;
import com.tlcn.service.UserService;


@Controller
public class LinkController {

	@Autowired
	private ContentService contentService;
	@Autowired
	private UserService userService;

	@RequestMapping(value = { "/", "/index" } )
	public ModelAndView mainPage(HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("home");
		session.setAttribute("username",null);
		session.setAttribute("role",null);
		List<Content> contents = contentService.getAll();
		modelAndView.addObject("content", contents);
		return modelAndView;
	}
	@RequestMapping(value="/logout")
	public String logout(ModelMap model, HttpSession session) throws Exception
	{
		session.setAttribute("username",null);
		session.setAttribute("role",null);
		List<Content> contents = contentService.getAll();
		model.addAttribute("content", contents);
		return "home";
	}

	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginPage(Model model) 
	{
		model.addAttribute("newuser", new User());
		return "login";
	}

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView doLoginPage(HttpServletRequest request, HttpSession session, @ModelAttribute @Valid User newuser, 
			BindingResult result, Model model) 
	{
		ModelAndView modelAndView=null;
		int admin=0;

		String role=request.getParameter("role");
		if(role.equals("User"))
		{
			admin=0;
		}
		else
		{
			admin=1;
		}
		if(!result.hasFieldErrors()) 
		{
			if(!userService.checkLogin(newuser,admin)) 
			{
				modelAndView = new ModelAndView("error");
				model.addAttribute("newuser", new User());
			} 
			else 
			{
				if(admin==1)
				{
					session.setAttribute("username", newuser.getUsername());//add sesion 
					session.setAttribute("role", admin);//add sesion 
					List<Content> contents_checked = contentService.getContent_daduyet();

					model.addAttribute("content", contents_checked);
					modelAndView = new ModelAndView("admin_denghidapheduyet");
				}
				else{
					session.setAttribute("username", newuser.getUsername());
					session.setAttribute("role", admin);
					List<Content> contents = contentService.getAll();
					model.addAttribute("content", contents);
					modelAndView = new ModelAndView("home");
				}

			}
		}
		else{
			modelAndView = new ModelAndView("login");
			model.addAttribute("newuser", new User());
		}
		return modelAndView;
	}

	@RequestMapping(value="{username}/{role}/themcontent", method=RequestMethod.GET)
	public ModelAndView ThemContent(@PathVariable String username
			,@PathVariable int role, HttpSession session) 
	{
		session.setAttribute("username", username);
		session.setAttribute("role", role);
		ModelAndView modelAndView = new ModelAndView("themcontent");
		modelAndView.addObject("newcontent", new Content());
		return modelAndView;
	}
	@RequestMapping(value="{username}/{role}/themcontent", method=RequestMethod.POST)
	@ResponseStatus(value=HttpStatus.OK)
	public ModelAndView addingTeam(@ModelAttribute Content newcontent, @PathVariable String username
			,@PathVariable int role, HttpSession session) {
		session.setAttribute("username", username);
		session.setAttribute("role", role);
		newcontent.setNguoidenghi(username);
		contentService.addContent(newcontent);
		ModelAndView modelAndView = new ModelAndView("home");

		List<Content> contents = contentService.getAll();
		modelAndView.addObject("content", contents);
		return modelAndView;
	}
	@RequestMapping(value="{username}/{role}/danhsachdenghidaduyet")
	public ModelAndView QuanLyHoatDong_DaPheDuyet(Model model,@PathVariable String username
			,@PathVariable int role, HttpSession session) 
	{
		session.setAttribute("username", username);
		session.setAttribute("role", role);
		ModelAndView modelAndView = new ModelAndView("admin_denghidapheduyet");
		List<Content> contents_checked = contentService.getContent_daduyet();

		modelAndView.addObject("content", contents_checked);
		return modelAndView;
	}
	@RequestMapping(value="{username}/{role}/danhsachdenghichuaduyet")
	public ModelAndView QuanLyHoatDong_ChuaPheDuyet(Model model,@PathVariable String username
			,@PathVariable int role, HttpSession session) 
	{
		session.setAttribute("username", username);
		session.setAttribute("role", role);
		ModelAndView modelAndView = new ModelAndView("admin_denghichuapheduyet");
		List<Content> contents_checked = contentService.getContent_chuaduyet();

		modelAndView.addObject("content", contents_checked);
		return modelAndView;
	}
	@RequestMapping(value="{username}/{role}/PheDuyetDeNghi", method=RequestMethod.GET)
	public ModelAndView showHoatDong(@RequestParam("id") Integer id, @PathVariable String username
			,@PathVariable int role, HttpSession session) {
		ModelAndView modelAndView = new ModelAndView("admin_pheduyetdenghi");

		Content cont = contentService.getContentByID(id);
		modelAndView.addObject("contentAttribute", cont);
		return modelAndView;
	}
	@RequestMapping(value="{username}/{role}/PheDuyetDeNghi", method = RequestMethod.POST)
	public String pheduyet(@PathVariable String username
			,@PathVariable int role, @RequestParam("id") Integer id, @ModelAttribute("contentAttribute") Content content, 
			ModelMap model, HttpSession session) {
		session.setAttribute("username", username);
		session.setAttribute("role", role);
		Content cont = new Content();
		cont.setId(id);

		contentService.updateContent_pheduyet(content,username);

		List<Content> contents_checked = contentService.getContent_daduyet();
		model.addAttribute("content", contents_checked);
		return "admin_denghidapheduyet";
	}

}
